"name this script as you like. don't mess with this file if you don't know what your doing."

import tkinter as tk

root = tk.Tk()

root.title("mod-by-waterfall")
root.geometry ("200x150")

"put your scripts here, delete the 'root.mainloop()' and put it at the end of your script."

label = tk.Label(root, text="Waterfall Menu")
label.pack(pady=20)

root.mainloop()